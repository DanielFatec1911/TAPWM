//var dbConnection = require('../config/dbConnection');  
module.exports = function(application){
    application.get('/admin/adicionar_professor', function(req,res){
        res.render('admin/adicionar_professor');
     });
   
  application.post('/professor/salvar', function(req,res){
        res.send("Salvo!!!!");
     });

   
  }

module.exports = function(app){
  app.get('/informacao/professores', function(req,res){
    async function geprofessores() {
           try {

               var connection = app.config.dbConnection;
               const pool = await connection();
               const results = await pool.request().query('SELECT * from PROFESSORES');
 
               res.render('informacao/professores',{profs :  results.recordset});
 
           } catch (err) {
               console.log(err)
           }
       }
 
  getProfessores();
   });
};